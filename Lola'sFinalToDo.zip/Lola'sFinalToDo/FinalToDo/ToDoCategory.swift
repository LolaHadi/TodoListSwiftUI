import Foundation

enum ToDoCategory {
    case Health
    case Study
    case Work
    case Social
    case Entertainment
    case SelfCare
    //    case Other: todos without gategories appears here.
}
